package com.transaction.master.util;

import java.util.UUID;

public class UtilService {
	public static UUID getUUID() {
		return UUID.randomUUID();

	}

}
