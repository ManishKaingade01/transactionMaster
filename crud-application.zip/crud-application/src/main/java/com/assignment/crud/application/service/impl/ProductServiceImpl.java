package com.assignment.crud.application.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.crud.application.dto.ProductRequest;
import com.assignment.crud.application.dto.ResponseStatus;
import com.assignment.crud.application.entity.Product;
import com.assignment.crud.application.exception.GenericException;
import com.assignment.crud.application.repository.ProductRepository;
import com.assignment.crud.application.service.ProductService;
import com.assignment.crud.application.util.ErrorCodes;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;

	@Override
	public Product addProduct(ProductRequest request) {
		try {
			checkIfProductAlreadyExisted(request.getProductName());

			Product product = Product.builder().productName(request.getProductName()).price(request.getPrice())
					.currentStock(request.getCurrentStock()).description(request.getDescription()).build();
			return productRepository.save(product);

		} catch (GenericException e) {
			throw e;
		} catch (Exception e) {
			throw new GenericException(ResponseStatus.builder().code(ErrorCodes.ER203.getCode())
					.message(ErrorCodes.ER203.getMessage()).build());
		}
	}

	private void checkIfProductAlreadyExisted(String productName) {

		productRepository.findByProductName(productName).ifPresent(product -> {
			throw new GenericException(ResponseStatus.builder().code(ErrorCodes.ER202.getCode())
					.message(ErrorCodes.ER202.getMessage()).build());
		});

	}

	@Override
	public List<Product> findAllPrdoducts() {
		return productRepository.findAll();
	}

	@Override
	public Product findProductById(Long id) {
		return Optional.ofNullable(productRepository.findOne(id)).orElseThrow(() -> new GenericException(ResponseStatus
				.builder().code(ErrorCodes.ER204.getCode()).message(ErrorCodes.ER204.getMessage()).build()));
	}

	@Override
	public Product updateProductById(Long id, ProductRequest request) {
		Product product = Optional.ofNullable(productRepository.findOne(id))
				.orElseThrow(() -> new GenericException(ResponseStatus.builder().code(ErrorCodes.ER204.getCode())
						.message(ErrorCodes.ER204.getMessage()).build()));
		product.setCurrentStock(request.getCurrentStock());
		product.setPrice(request.getPrice());
		product.setDescription(request.getDescription());
		product.setProductName(request.getProductName());

		return productRepository.save(product);
	}

	@Override
	public ResponseStatus deleteProductById(Long id) {
		Optional.ofNullable(productRepository.findOne(id)).orElseThrow(() -> new GenericException(ResponseStatus
				.builder().code(ErrorCodes.ER204.getCode()).message(ErrorCodes.ER204.getMessage()).build()));
		productRepository.delete(id);
		return ResponseStatus.builder().code(ErrorCodes.ER200.getCode()).message(ErrorCodes.ER200.getMessage() + id)
				.build();
	}

}
